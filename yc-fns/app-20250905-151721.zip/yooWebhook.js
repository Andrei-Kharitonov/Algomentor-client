"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const crypto_1 = require("crypto");
const common_1 = require("./common");
// ---------- type guards & helpers ----------
const isRecord = (v) => typeof v === 'object' && v !== null;
const isString = (v) => typeof v === 'string';
const parseIntLoose = (v) => {
    if (typeof v === 'number' && Number.isFinite(v))
        return v;
    if (typeof v === 'string') {
        const n = parseInt(v, 10);
        return Number.isFinite(n) ? n : null;
    }
    return null;
};
const isYkPaymentObject = (v) => isRecord(v) && isString(v.id);
const isYkWebhookPayload = (v) => isRecord(v) && isString(v.event);
function verifyBasic(header) {
    if (!header)
        return false;
    const { SHOP_ID, SECRET_KEY } = process.env;
    if (!SHOP_ID || !SECRET_KEY)
        return false;
    const expected = 'Basic ' + Buffer.from(`${SHOP_ID}:${SECRET_KEY}`).toString('base64');
    const a = Buffer.from(header.trim());
    const b = Buffer.from(expected);
    return a.length === b.length && (0, crypto_1.timingSafeEqual)(a, b);
}
function verifyQuerySecret(qsSecret) {
    const expected = process.env.WEBHOOK_SECRET;
    if (!expected)
        return false;
    return (qsSecret ?? '') === expected;
}
// accepts multiple key variants commonly used by providers / backends
function normalizePaymentMeta(m) {
    if (!isRecord(m))
        return null;
    // uid variants
    const uidRaw = m.uid ??
        m.userId ??
        m.user_id ??
        m.customer_uid;
    const tariffRaw = m.tariff ??
        m.plan ??
        m.plan_id;
    const daysRaw = m.periodDays ??
        m.period_days ??
        m.days;
    const uid = isString(uidRaw) ? uidRaw : null;
    const tariff = isString(tariffRaw) ? tariffRaw : null;
    const periodDays = parseIntLoose(daysRaw);
    if (!uid || !tariff || periodDays == null) {
        console.error('metadata missing fields', {
            hasUid: Boolean(uid),
            hasTariff: Boolean(tariff),
            hasDays: periodDays != null,
            raw: m,
        });
        return null;
    }
    return { uid, tariff, periodDays };
}
// ---------- handler ----------
const handler = async (event) => {
    // 1) auth
    const h = event.headers ?? {};
    const authHeader = h.authorization ??
        h.Authorization ??
        h['x-original-authorization'] ??
        h['X-Original-Authorization'] ??
        null;
    const qsSecret = event.queryStringParameters?.hook_secret ?? null;
    if (!verifyBasic(authHeader) && !verifyQuerySecret(qsSecret)) {
        console.warn('unauthorized webhook', { hasAuthHeader: Boolean(authHeader), hasQsSecret: Boolean(qsSecret) });
        return { statusCode: 401, body: 'bad auth' };
    }
    // 2) parse JSON
    const raw = event.isBase64Encoded
        ? Buffer.from(event.body ?? '', 'base64').toString('utf-8')
        : (event.body ?? '{}');
    let unknownPayload;
    try {
        unknownPayload = JSON.parse(raw);
    }
    catch (e) {
        console.error('bad json', { raw, err: String(e) });
        return { statusCode: 400, body: 'bad json' };
    }
    if (!isYkWebhookPayload(unknownPayload)) {
        console.error('bad payload shape', { payload: unknownPayload });
        return { statusCode: 400, body: 'bad payload' };
    }
    const payload = unknownPayload;
    // 3) only payments we care about
    if (payload.event !== 'payment.succeeded') {
        return { statusCode: 200, body: 'ignored' };
    }
    if (!payload.object || !isYkPaymentObject(payload.object)) {
        console.error('missing object', { payload });
        return { statusCode: 400, body: 'missing object' };
    }
    const paymentId = payload.object.id;
    // 4) get metadata (from webhook first, then fallback to API)
    let meta = normalizePaymentMeta(payload.object.metadata);
    if (!meta) {
        try {
            const fetched = await common_1.checkout.getPayment(paymentId);
            const fetchedMeta = isRecord(fetched) && 'metadata' in fetched
                ? fetched.metadata
                : undefined;
            meta = normalizePaymentMeta(fetchedMeta);
        }
        catch (e) {
            console.error('getPayment failed', { paymentId, err: String(e) });
        }
    }
    if (!meta) {
        console.error('missing meta after all attempts', {
            paymentId,
            webhookMeta: payload.object.metadata,
        });
        return { statusCode: 400, body: 'missing meta' };
    }
    // 5) compute period & write to Firestore (creates collection/doc if absent)
    const now = Date.now();
    const periodEnd = now + meta.periodDays * 86400000; // 86400 * 1000
    const subRef = common_1.firestore.doc(`subscriptions/${meta.uid}`);
    try {
        await common_1.firestore.runTransaction(async (tx) => {
            const snap = await tx.get(subRef);
            const prev = (snap.exists ? snap.data() : undefined);
            // idem-potent: if this payment already processed — no-op
            if (prev?.paymentId === paymentId) {
                console.info('duplicate payment, skipping', { uid: meta.uid, paymentId });
                return 'noop';
            }
            const update = {
                uid: meta.uid,
                status: 'active',
                plan: meta.tariff,
                period_end: periodEnd,
                paymentId,
                updated_at: now,
            };
            tx.set(subRef, update, { merge: true }); // <-- creates doc (and collection) if not exists
            return 'updated';
        });
    }
    catch (e) {
        console.error('firestore transaction failed', { uid: meta.uid, paymentId, err: String(e) });
        return { statusCode: 500, body: 'retry later' };
    }
    return { statusCode: 200, body: 'OK' };
};
exports.handler = handler;
