"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const uuid_1 = require("uuid");
const common_1 = require("./common");
const handler = async (event) => {
    const origin = process.env.FRONT_ORIGIN ?? '*';
    const headers = {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, X-Firebase-Token',
        'Access-Control-Max-Age': '86400',
        'Content-Type': 'application/json',
        Vary: 'Origin'
    };
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 204, headers, body: '' };
    }
    try {
        const token = event.headers['X-Firebase-Token'] || event.headers['x-firebase-token'];
        console.log('HEADERS', event.headers);
        console.log('TOKEN-HEAD', token?.slice(0, 30) + '…');
        if (!token) {
            return { statusCode: 401, headers, body: JSON.stringify({ error: 'No token' }) };
        }
        let uid;
        try {
            ({ uid } = await common_1.authAdmin.verifyIdToken(token));
            console.log('verify OK', uid);
        }
        catch (e) {
            console.error('verify FAIL', e);
            throw e;
        }
        const { tariff = 'basic' } = JSON.parse(event.body || '{}');
        if (!common_1.PLANS[tariff]) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Bad tariff' }) };
        }
        const plan = common_1.PLANS[tariff];
        console.log('ENV', {
            SHOP_ID: process.env.SHOP_ID,
            SECRET_KEY: process.env.SECRET_KEY?.slice(0, 15) + '…'
        });
        const payment = await common_1.checkout.createPayment({
            amount: plan.amount,
            confirmation: { type: 'redirect', return_url: 'http://localhost:5173' },
            description: `Algomentor ${tariff}`,
            metadata: { uid, tariff, periodDays: plan.days }
        }, (0, uuid_1.v4)());
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ confirmationUrl: payment.confirmation.confirmation_url })
        };
    }
    catch (err) {
        console.error('PAYMENT_ERROR', {
            statusCode: err?.statusCode,
            message: err?.message,
            response: err?.response?.data ?? err?.body ?? err
        });
        const code = err?.statusCode ?? 500;
        return {
            statusCode: code,
            headers,
            body: JSON.stringify({
                error: err?.message ?? 'Unknown error',
                details: err?.response?.data ?? err?.body ?? null
            })
        };
    }
};
exports.handler = handler;
