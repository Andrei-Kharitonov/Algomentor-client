"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const crypto_1 = require("crypto");
const common_1 = require("./common");
/* ===== utils / guards ===== */
const isRecord = (v) => typeof v === 'object' && v !== null;
const isString = (v) => typeof v === 'string';
const isTariff = (v) => typeof v === 'string';
const parseDays = (v) => {
    if (typeof v === 'number' && Number.isFinite(v))
        return v;
    if (typeof v === 'string') {
        const n = parseInt(v, 10);
        return Number.isFinite(n) ? n : null;
    }
    return null;
};
const isYkPaymentObject = (v) => isRecord(v) && isString(v.id);
const isYkWebhookPayload = (v) => isRecord(v) && isString(v.event);
const toPaymentMeta = (m) => {
    if (!isRecord(m))
        return null;
    const uid = m.uid;
    const tariff = m.tariff;
    const days = parseDays(m.periodDays);
    if (!isString(uid) || !isTariff(tariff) || days === null)
        return null;
    return { uid, tariff, periodDays: days };
};
/* ===== auth helpers ===== */
function verifyBasic(header) {
    if (!header)
        return false;
    const { SHOP_ID, SECRET_KEY } = process.env;
    if (!SHOP_ID || !SECRET_KEY)
        return false;
    const expected = 'Basic ' + Buffer.from(`${SHOP_ID}:${SECRET_KEY}`).toString('base64');
    const a = Buffer.from(header.trim());
    const b = Buffer.from(expected);
    return a.length === b.length && (0, crypto_1.timingSafeEqual)(a, b);
}
function verifyQuerySecret(qsSecret) {
    const expected = process.env.WEBHOOK_SECRET;
    if (!expected)
        return false;
    return (qsSecret ?? '') === expected;
}
/* ===== handler ===== */
const handler = async (event) => {
    // 1) Auth: Basic либо hook_secret в query (на случай, если API-Gateway не прокинет Authorization)
    const h = event.headers ?? {};
    const authHeader = h.authorization ??
        h.Authorization ??
        h['x-original-authorization'] ??
        h['X-Original-Authorization'] ??
        null;
    const qsSecret = event.queryStringParameters?.hook_secret ?? null;
    if (!verifyBasic(authHeader) && !verifyQuerySecret(qsSecret)) {
        return { statusCode: 401, body: 'bad auth' };
    }
    // 2) JSON (учтём base64)
    const raw = event.isBase64Encoded
        ? Buffer.from(event.body ?? '', 'base64').toString('utf-8')
        : (event.body ?? '{}');
    let unknownPayload;
    try {
        unknownPayload = JSON.parse(raw);
    }
    catch {
        return { statusCode: 400, body: 'bad json' };
    }
    if (!isYkWebhookPayload(unknownPayload)) {
        return { statusCode: 400, body: 'bad payload' };
    }
    const payload = unknownPayload;
    if (payload.event !== 'payment.succeeded') {
        return { statusCode: 200, body: 'ignored' };
    }
    if (!payload.object || !isYkPaymentObject(payload.object)) {
        return { statusCode: 400, body: 'missing object' };
    }
    const paymentId = payload.object.id;
    // 3) metadata: берем из события, если нет — дотягиваем getPayment
    let meta = toPaymentMeta(payload.object.metadata);
    if (!meta) {
        try {
            const fetched = await common_1.checkout.getPayment(paymentId);
            const fetchedMeta = isRecord(fetched) && 'metadata' in fetched
                ? fetched.metadata
                : undefined;
            meta = toPaymentMeta(fetchedMeta);
        }
        catch (e) {
            console.error('getPayment failed', e);
        }
    }
    if (!meta) {
        console.error('missing meta', { paymentId, meta: payload.object.metadata });
        return { statusCode: 400, body: 'missing meta' };
    }
    // 4) Идемпотентная запись
    const subRef = common_1.firestore.doc(`subscriptions/${meta.uid}`);
    const periodEnd = Date.now() + meta.periodDays * 86400000;
    try {
        await common_1.firestore.runTransaction(async (tx) => {
            const snap = await tx.get(subRef);
            const prev = snap.data();
            if (prev?.paymentId === paymentId)
                return;
            const update = {
                uid: meta.uid, // пишем uid и как поле (чтобы было видно в документе)
                status: 'active',
                plan: meta.tariff,
                period_end: periodEnd,
                paymentId,
                updated_at: Date.now(),
            };
            tx.set(subRef, update, { merge: true });
        });
    }
    catch (e) {
        console.error('firestore tx failed', e);
        return { statusCode: 500, body: 'retry later' };
    }
    return { statusCode: 200, body: 'OK' };
};
exports.handler = handler;
