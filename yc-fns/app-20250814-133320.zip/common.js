"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLANS = exports.checkout = exports.firestore = exports.authAdmin = void 0;
const yoo_checkout_1 = require("@a2seven/yoo-checkout");
const app_1 = require("firebase-admin/app");
const auth_1 = require("firebase-admin/auth");
const firestore_1 = require("firebase-admin/firestore");
const saBase64 = process.env.FB_SERVICE_ACCOUNT_B64;
const saJsonRaw = saBase64
    ? Buffer.from(saBase64, 'base64').toString('utf-8')
    : process.env.FB_SERVICE_ACCOUNT_JSON;
if (!saJsonRaw) {
    throw new Error('Firebase service account is missing. Set FB_SERVICE_ACCOUNT_B64 or FB_SERVICE_ACCOUNT_JSON env var.');
}
const serviceJson = JSON.parse(saJsonRaw);
(0, app_1.initializeApp)({ credential: (0, app_1.cert)(serviceJson) });
exports.authAdmin = (0, auth_1.getAuth)();
exports.firestore = (0, firestore_1.getFirestore)();
exports.checkout = new yoo_checkout_1.YooCheckout({
    shopId: process.env.SHOP_ID,
    secretKey: process.env.SECRET_KEY
});
exports.PLANS = {
    basic: { amount: { value: '2990.00', currency: 'RUB' }, days: 30 },
    basic365: { amount: { value: '19990.00', currency: 'RUB' }, days: 365 },
    pro: { amount: { value: '3990.00', currency: 'RUB' }, days: 30 },
    pro365: { amount: { value: '24990.00', currency: 'RUB' }, days: 365 }
};
